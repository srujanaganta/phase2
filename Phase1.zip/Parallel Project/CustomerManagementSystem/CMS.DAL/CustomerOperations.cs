﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using System.Runtime.Serialization.Formatters.Binary;
using Entity;
using CMS.Exception;

namespace CMS.DAL
{
    public class CustomerOperations
    {
        static List<Customer> custList = new List<Customer>();

        public static bool AddCustomer(Customer cust)
        {
            bool custAdded = false;

            try
            {
                custList.Add(cust);
                custAdded = true;
            }
            catch (CustomerException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return custAdded;
        }

        public static bool UpdateCustomer(Customer cust)
        {
            bool custUpdated = false;

            try
            {
                for (int i = 0; i < custList.Count; i++)
                {
                    if (custList[i].CustomerID == cust.CustomerID)
                    {
                        custList[i].CustomerName = cust.CustomerName;
                        custList[i].City = cust.City;
                        custList[i].Age = cust.Age;
                        custList[i].Phone = cust.Phone;
                        custList[i].Pincode = cust.Pincode;
                        custUpdated = true;
                    }
                }
            }
            catch (CustomerException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return custUpdated;
        }

        public static bool DeleteCustomer(int id)
        {
            bool custDeleted = false;

            try
            {
                Customer cust = custList.Find(c => c.CustomerID == id);

                if (cust != null)
                {
                    custList.Remove(cust);
                    custDeleted = true;
                }
            }
            catch (CustomerException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return custDeleted;
        }

        public static Customer SearchCustomer(int id)
        {
            Customer cust = null;

            try
            {
                cust = custList.Find(c => c.CustomerID == id);
            }
            catch (CustomerException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return cust;
        }

        public static List<Customer> RetrieveCustomers()
        {
            return custList;
        }

        public static bool SerializeCustomer()
        {
            bool custSerialized = false;

            try
            {
                FileStream fs = new FileStream("Cust.txt", FileMode.Create, FileAccess.Write);
                BinaryFormatter bin = new BinaryFormatter();
                bin.Serialize(fs, custList);
                fs.Close();
                custSerialized = true;
            }
            catch (CustomerException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return custSerialized;
        }

        public static List<Customer> DeserializeCustomer()
        {
            List<Customer> desCustList = null;

            try
            {
                FileStream fs = new FileStream("Cust.txt", FileMode.Open, FileAccess.Read);
                BinaryFormatter bin = new BinaryFormatter();
                desCustList = bin.Deserialize(fs) as List<Customer>;
                fs.Close();
            }
            catch (CustomerException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return desCustList;
        }
    }
}
