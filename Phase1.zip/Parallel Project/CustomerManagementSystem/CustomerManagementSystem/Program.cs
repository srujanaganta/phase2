﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using CMS.BL;
using CMS.Exception;
using Entity;

namespace CustomerManagementSystem
{
    class Program
    {
        public static void AddCustomer()
        {
            Customer cust = new Customer();

            try
            {
                Console.Write("Enter Customer ID : ");
                cust.CustomerID = Convert.ToInt32(Console.ReadLine());
                Console.Write("Enter Customer Name : ");
                cust.CustomerName = Console.ReadLine();
                Console.Write("Enter City : ");
                cust.City = Console.ReadLine();
                Console.Write("Enter Customer Age : ");
                cust.Age = Convert.ToInt32(Console.ReadLine());
                Console.Write("Enter Customer Phone : ");
                cust.Phone = Console.ReadLine();
                Console.Write("Enter Customer Pincode : ");
                cust.Pincode = Convert.ToInt32(Console.ReadLine());

                bool custAdded = CustomerValidation.AddCustomer(cust);

                if (custAdded)
                {
                    Console.WriteLine("Customer Added Successfully");
                }
                else
                    throw new CustomerException("Customer Details not Added");

            }
            catch (CustomerException ex)
            {
                Console.WriteLine(ex.Message);
            }
            catch (SystemException ex)
            {
                Console.WriteLine(ex.Message);
            }
        }

        public static void UpdateCustomer()
        {
            Customer cust = new Customer();

            try
            {
                Console.Write("Enter Customer ID to be Updated : ");
                cust.CustomerID = Convert.ToInt32(Console.ReadLine());
                Console.Write("Enter Customer Name to be Updated : ");
                cust.CustomerName = Console.ReadLine();
                Console.Write("Enter City to be Updated: ");
                cust.City = Console.ReadLine();
                Console.Write("Enter age of customer to be Updated: ");
                cust.Age = Convert.ToInt32(Console.ReadLine());
                Console.Write("Enter Customer Phone to be updated: ");
                cust.Phone = Console.ReadLine();
                Console.Write("Enter Customer Pincode to be updated : ");
                cust.Pincode = Convert.ToInt32(Console.ReadLine());

                bool custUpdated = CustomerValidation.UpdateCustomer(cust);

                if (custUpdated)
                {
                    Console.WriteLine("Customer Updated Successfully");
                }
                else
                    throw new CustomerException("Customer Details not Updated");

            }
            catch (CustomerException ex)
            {
                Console.WriteLine(ex.Message);
            }
            catch (SystemException ex)
            {
                Console.WriteLine(ex.Message);
            }
        }

        public static void DeleteCustomer()
        {
            int id;

            try
            {
                Console.Write("Enter Customer ID to be Deleted : ");
                id = Convert.ToInt32(Console.ReadLine());

                bool custdeleted = CustomerValidation.DeleteCustomer(id);

                if (custdeleted)
                {
                    Console.WriteLine("Customer Deleted Successfully");
                }
                else
                    throw new CustomerException("Customer not deleted");
            }
            catch (CustomerException ex)
            {
                Console.WriteLine(ex.Message);
            }
            catch (SystemException ex)
            {
                Console.WriteLine(ex.Message);
            }
        }

        public static void SearchCustomer()
        {
            int id;
            Customer cust = null;

            try
            {
                Console.Write("Enter Customer ID to be Searched : ");
                id = Convert.ToInt32(Console.ReadLine());

                cust = CustomerValidation.SearchCustomer(id);

                if (cust != null)
                {
                    Console.WriteLine("Customer ID : " + cust.CustomerID);
                    Console.WriteLine("Customer Name : " + cust.CustomerName);
                    Console.WriteLine("City : " + cust.City);
                    Console.WriteLine("Age : " + cust.Age);
                    Console.WriteLine("Phone : " + cust.Phone);
                    Console.WriteLine("Pincode : " + cust.Pincode);
                }
                else
                    throw new CustomerException("Customer not found");
            }
            catch (CustomerException ex)
            {
                Console.WriteLine(ex.Message);
            }
            catch (SystemException ex)
            {
                Console.WriteLine(ex.Message);
            }
        }

        public static void RetrieveCustomers()
        {
            try
            {
                List<Customer> custList = CustomerValidation.RetrieveCustomers();

                if (custList.Count > 0)
                {
                    Console.WriteLine("------------------------------------------------------------------------------------");
                    Console.WriteLine("Customer ID        Customer Name          City    Age      Phone         Pincode");
                    Console.WriteLine("------------------------------------------------------------------------------------");
                    foreach (Customer cust in custList)
                    {
                        Console.WriteLine($"{cust.CustomerID} \t {cust.CustomerName} \t {cust.City} \t {cust.Age} \t {cust.Phone} \t {cust.Pincode}");
                    }
                    Console.WriteLine("-------------------------------------------------------------------------------------");
                }
                else
                {
                    throw new CustomerException("Customer Details not Available");
                }
            }
            catch (CustomerException ex)
            {
                Console.WriteLine(ex.Message);
            }
            catch (SystemException ex)
            {
                Console.WriteLine(ex.Message);
            }
        }

        public static void SerializeCustomer()
        {
            try
            {
                bool custSerialized = CustomerValidation.SerializeCustomer();

                if (custSerialized)
                {
                    Console.WriteLine("Customer details serialized successfully");
                }
                else
                {
                    throw new CustomerException("Customer Details not Serialized");
                }
            }
            catch (CustomerException ex)
            {
                Console.WriteLine(ex.Message);
            }
            catch (SystemException ex)
            {
                Console.WriteLine(ex.Message);
            }
        }

        public static void DeserializeCustomers()
        {
            try
            {
                List<Customer> custList = CustomerValidation.DeserializeCustomer();

                if (custList.Count > 0)
                {
                    Console.WriteLine("------------------------------------------------------------------------------------");
                    Console.WriteLine("Customer ID        Customer Name          City    Age      Phone         Pincode");
                    Console.WriteLine("------------------------------------------------------------------------------------");
                    foreach (Customer cust in custList)
                    {
                        Console.WriteLine($"{cust.CustomerID} \t {cust.CustomerName} \t {cust.City} \t {cust.Age} \t {cust.Phone} \t {cust.Pincode}");
                    }
                    Console.WriteLine("-------------------------------------------------------------------------------------");
                }
                else
                {
                    throw new CustomerException("Customer Details not Deserialized");
                }
            }
            catch (CustomerException ex)
            {
                Console.WriteLine(ex.Message);
            }
            catch (SystemException ex)
            {
                Console.WriteLine(ex.Message);
            }
        }

        public static void PrintMenu()
        {
            Console.WriteLine("**************************");
            Console.WriteLine("1. Add Customer");
            Console.WriteLine("2. Update Customer");
            Console.WriteLine("3. Delete Customer");
            Console.WriteLine("4. Search Customer");
            Console.WriteLine("5. Retrieve Customer");
            Console.WriteLine("6. Serialize Customer");
            Console.WriteLine("7. Deserialize Customer");
            Console.WriteLine("8. Exit");
            Console.WriteLine("**************************");
        }

        static void Main(string[] args)
        {
            int choice;

            try
            {
                do
                {
                    PrintMenu();
                    Console.Write("Enter your choice : ");
                    choice = Convert.ToInt32(Console.ReadLine());
                    switch (choice)
                    {
                        case 1:
                            AddCustomer();
                            break;
                        case 2:
                            UpdateCustomer();
                            break;
                        case 3:
                            DeleteCustomer();
                            break;
                        case 4:
                            SearchCustomer();
                            break;
                        case 5:
                            RetrieveCustomers();
                            break;
                        case 6:
                            SerializeCustomer();
                            break;
                        case 7:
                            DeserializeCustomers();
                            break;
                        case 8:
                            Environment.Exit(0);
                            break;
                        default:
                            Console.WriteLine("Please make valid choice");
                            break;
                    }
                } while (choice != 8);
            }
            catch (SystemException ex)
            {
                Console.WriteLine(ex.Message);
            }
        }
    }
}
