﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Text.RegularExpressions;
using Entity;
using CMS.Exception;
using CMS.DAL;

namespace CMS.BL
{
    public class CustomerValidation
    {
        public static bool ValidateCustomer(Customer cust)
        {
            bool custValidated = true;
            StringBuilder message = new StringBuilder();

            try
            {
                if (cust.CustomerID < 100000 || cust.CustomerID > 999999)
                {
                    custValidated = false;
                    message.Append("Customer ID should be 6 digits long\n");
                }

                if (string.IsNullOrEmpty(cust.CustomerName))
                {
                    custValidated = false;
                    message.Append("Customer Name should be provided\n");
                }
                else if (!Regex.IsMatch(cust.CustomerName, "[A-Z][a-z]+"))
                {
                    custValidated = false;
                    message.Append("Customer Name should start with capital alphabet and it should have alphabets only\n");
                }

                if (string.IsNullOrEmpty(cust.City))
                {
                    custValidated = false;
                    message.Append("City should be provided\n");
                }

                if (cust.Age < 0)
                {
                    custValidated = false;
                    message.Append("Age should not be negative\n");
                }

                if (string.IsNullOrEmpty(cust.Phone))
                {
                    custValidated = false;
                    message.Append("Phone should be provided\n");
                }
                else if (!Regex.Equals(cust.Phone, "[0-9]{10}"))
                if (custValidated == false)
                {
                    throw new CustomerException(message.ToString());
                }

                if (cust.Pincode < 0)
                {
                    custValidated = false;
                    message.Append("Pincode should not be negative\n");
                }
            }
            catch (CustomerException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return custValidated;
        }

        public static bool AddCustomer(Customer cust)
        {
            bool custAdded = true;

            try
            {
                if (ValidateCustomer(cust))
                {
                    custAdded = CustomerOperations.AddCustomer(cust);
                }
                else
                    throw new CustomerException("Please provide valid customer details");
            }
            catch (CustomerException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return custAdded;
        }

        public static bool UpdateCustomer(Customer cust)
        {
            bool custUpdated = false;

            try
            {
                if (ValidateCustomer(cust))
                {
                    custUpdated = CustomerOperations.UpdateCustomer(cust);
                }
                else
                    throw new CustomerException("Please provide valid customer details for update");
            }
            catch (CustomerException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return custUpdated;
        }

        public static bool DeleteCustomer(int id)
        {
            bool custDeleted = false;

            try
            {
                custDeleted = CustomerOperations.DeleteCustomer(id);
            }
            catch (CustomerException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return custDeleted;
        }

        public static Customer SearchCustomer(int id)
        {
            Customer cust = null;

            try
            {
                cust = CustomerOperations.SearchCustomer(id);
            }
            catch (CustomerException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return cust;
        }

        public static List<Customer> RetrieveCustomers()
        {
            List<Customer> custList = null;

            try
            {
                custList = CustomerOperations.RetrieveCustomers();
            }
            catch (CustomerException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return custList;
        }

        public static bool SerializeCustomer()
        {
            bool custSerialized = false;

            try
            {
                custSerialized = CustomerOperations.SerializeCustomer();
            }
            catch (CustomerException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return custSerialized;
        }

        public static List<Customer> DeserializeCustomer()
        {
            List<Customer> custList = null;

            try
            {
                custList = CustomerOperations.DeserializeCustomer();
            }
            catch (CustomerException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return custList;
        }
    }
}
