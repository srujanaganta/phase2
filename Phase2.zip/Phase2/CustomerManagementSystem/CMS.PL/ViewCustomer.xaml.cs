﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using Entity;
using CMS.BL;
using CMS.Exception;

namespace CMS.PL
{
    /// <summary>
    /// Interaction logic for ViewCustomer.xaml
    /// </summary>
    public partial class ViewCustomer : Window
    {
        public ViewCustomer()
        {
            InitializeComponent();
            List<Customer> customerList = CustomerValidation.GetAllCustomerBL();
            dgCustomers.ItemsSource = customerList.ToList();
        }
    }
}
