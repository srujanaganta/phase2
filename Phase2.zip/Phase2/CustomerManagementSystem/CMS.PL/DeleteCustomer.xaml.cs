﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using Entity;
using CMS.Exception;
using CMS.BL;

namespace CMS.PL
{
    /// <summary>
    /// Interaction logic for DeleteCustomer.xaml
    /// </summary>
    public partial class DeleteCustomer : Window
    {
        public DeleteCustomer()
        {
            InitializeComponent();
        }

        private void btnDelete_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                int deleteCustomerID;
                deleteCustomerID = Convert.ToInt32(txtID.Text);
                //Guest deleteGuest = EmployeeBL.SearchGuestBL(deleteGuestID);
                //if (deleteGuest != null)
                //{
                //    bool guestdeleted = GuestBL.DeleteGuestBL(deleteGuestID);
                //    if (guestdeleted)
                //        Console.WriteLine("Guest Deleted");
                //    else
                //        Console.WriteLine("Guest not Deleted ");
                //}
                //else
                //{
                //    Console.WriteLine("No Guest Details Available");
                //}
                bool customerdeleted = CustomerValidation.DeleteCustomerBL(deleteCustomerID);
                if (customerdeleted)
                    MessageBox.Show("Customer Deleted");
                else
                    MessageBox.Show("Customer not Deleted ");
            }
            catch (CustomerException ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
    }
}
