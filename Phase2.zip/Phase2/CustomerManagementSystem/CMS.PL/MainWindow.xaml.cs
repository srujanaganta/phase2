﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace CMS.PL
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
            this.WindowStartupLocation = WindowStartupLocation.CenterScreen;
        }

        private void DisableAllButtons()
        {
            btnAddCustomer.IsEnabled = false;
            btnDeleteCustomer.IsEnabled = false;
            btnSearchCustomer.IsEnabled = false;
            btnUpdateCustomer.IsEnabled = false;
            btnGetCustomer.IsEnabled = false;
            btnExit.IsEnabled = false;
        }

        public void EnableAllButtons()
        {
            btnAddCustomer.IsEnabled = true;
            btnDeleteCustomer.IsEnabled = true;
            btnSearchCustomer.IsEnabled = true;
            btnUpdateCustomer.IsEnabled = true;
            btnGetCustomer.IsEnabled = true;
            btnExit.IsEnabled = true;
        }

        private void btnAddCustomer_Click(object sender, RoutedEventArgs e)
        {
            AddCustomer winadd = new AddCustomer();
            winadd.WindowStartupLocation = WindowStartupLocation.CenterScreen;
            winadd.Show();
            DisableAllButtons();
        }

        private void btnUpdateCustomer_Click(object sender, RoutedEventArgs e)
        {
            UpdateCustomer winupdate = new UpdateCustomer();
            winupdate.WindowStartupLocation = WindowStartupLocation.CenterScreen;
            winupdate.Show();
            DisableAllButtons();
        }

        private void btnDeleteCustomer_Click(object sender, RoutedEventArgs e)
        {
            DeleteCustomer windelete = new DeleteCustomer();
            windelete.WindowStartupLocation = WindowStartupLocation.CenterScreen;
            windelete.Show();
            DisableAllButtons();
        }

        private void btnSearchCustomer_Click(object sender, RoutedEventArgs e)
        {
            SearchCustomer winsearch = new SearchCustomer();
            winsearch.WindowStartupLocation = WindowStartupLocation.CenterScreen;
            winsearch.Show();
            DisableAllButtons();
        }

        private void btnGetCustomer_Click(object sender, RoutedEventArgs e)
        {
            ViewCustomer winview = new ViewCustomer();
            winview.WindowStartupLocation = WindowStartupLocation.CenterScreen;
            winview.Show();
            DisableAllButtons();
        }

        private void BtnExit_Click(object sender, RoutedEventArgs e)
        {
            this.Visibility = Visibility.Hidden;
        }

        private void Window_MouseEnter(object sender, MouseEventArgs e)
        {
            EnableAllButtons();
        }
    }
}
