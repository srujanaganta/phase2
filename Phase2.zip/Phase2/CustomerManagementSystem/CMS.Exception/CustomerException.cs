﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Runtime.Serialization;

namespace CMS.Exception
{
    public class CustomerException : ApplicationException
    {
        public CustomerException() : base()
        { }

        public CustomerException(string message) : base(message)
        { }
    }
}
