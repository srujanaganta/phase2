﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Entity;
using CMS.Exception;
using CMS.DAL;
using System.Text.RegularExpressions;

namespace CMS.BL
{
    public class CustomerValidation
    {
        public static bool ValidateCustomer(Customer cust)
        {
            bool custValidated = true;
            StringBuilder message = new StringBuilder();

            try
            {
                if (cust.CustomerID < 100000 || cust.CustomerID > 999999)
                {
                    custValidated = false;
                    message.Append("Customer ID should be 6 digits long\n");
                }

                if (string.IsNullOrEmpty(cust.CustomerName))
                {
                    custValidated = false;
                    message.Append("Customer Name should be provided\n");
                }
                else if (!Regex.IsMatch(cust.CustomerName, "[A-Z][a-z]+"))
                {
                    custValidated = false;
                    message.Append("Customer Name should start with capital alphabet and it should have alphabets only\n");
                }

                if (string.IsNullOrEmpty(cust.City))
                {
                    custValidated = false;
                    message.Append("City should be provided\n");
                }

                if (cust.Age < 0)
                {
                    custValidated = false;
                    message.Append("Age should not be negative\n");
                }

                if (string.IsNullOrEmpty(cust.Phone))
                {
                    custValidated = false;
                    message.Append("Phone should be provided\n");
                }
                else if (!Regex.Equals(cust.Phone, "[0-9]{10}"))
                    if (custValidated == false)
                    {
                        throw new CustomerException(message.ToString());
                    }

                if (cust.Pincode < 0)
                {
                    custValidated = false;
                    message.Append("Pincode should not be negative\n");
                }
            }
            catch (CustomerException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return custValidated;
        }

        public static bool AddCustomerBL(Customer newCustomer)
        {
            bool customerAdded = false;
            try
            {
                if (ValidateCustomer(newCustomer))
                {
                    CustomerOperations customerDAL = new CustomerOperations();
                    customerAdded = customerDAL.AddCustomerDAL(newCustomer);
                }
            }
            catch (CustomerException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return customerAdded;
        }

        public static List<Customer> GetAllCustomerBL()
        {
            List<Customer> customerList = null;
            try
            {
                CustomerOperations customerDAL = new CustomerOperations();
                customerList = customerDAL.GetAllCustomerDAL();
            }
            catch (CustomerException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }
            return customerList;
        }

        public static Customer SearchCustomerBL(int searchCustomerID)
        {
            Customer searchCustomer = null;
            try
            {
                CustomerOperations customerDAL = new CustomerOperations();
                searchCustomer = customerDAL.SearchCustomerDAL(searchCustomerID);
            }
            catch (CustomerException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }
            return searchCustomer;

        }

        public static bool UpdateCustomerBL(Customer updateCustomer)
        {
            bool customerUpdated = false;
            try
            {
                if (ValidateCustomer(updateCustomer))
                {
                    CustomerOperations customerDAL = new CustomerOperations();
                    customerUpdated = customerDAL.UpdateCustomerDAL(updateCustomer);
                }
            }
            catch (CustomerException)
            {
                throw;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return customerUpdated;
        }

        public static bool DeleteCustomerBL(int deleteCustomerID)
        {
            bool customerDeleted = false;
            try
            {
                if (deleteCustomerID > 0)
                {
                    CustomerOperations customerDAL = new CustomerOperations();
                    customerDeleted = customerDAL.DeleteCustomerDAL(deleteCustomerID);
                }
                else
                {
                    throw new CustomerException("Invalid Customer ID");
                }
            }
            catch (CustomerException)
            {
                throw;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return customerDeleted;
        }



    }
}
